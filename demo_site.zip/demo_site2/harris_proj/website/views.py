from django.shortcuts import render
from .models import Target #.within the current folder -> website.models

# Create your views here.
